<?php

include("../../bd/conexion.php");
include("../../models/cambiar_password/cambiar_password.php");
  //print_r($_POST);
  $tra=new Usuario();
  $tra->cambiar_password_admin(
	$_POST["id_registro"],
	hash('sha512', $_POST["password_actual"]),
	hash('sha512', $_POST["nuevo_password"]),
	hash('sha512', $_POST["repita_password"]));
?>
